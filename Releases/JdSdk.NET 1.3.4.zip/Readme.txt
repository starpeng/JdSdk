﻿jos .net sdk 
JingDong open service sdk for .net.
京东开放平台.NET版sdk

源码地址
https://github.com/starpeng/JdSdk


交流QQ群：236361019




the Json lib use Json.NET https://json.codeplex.com/